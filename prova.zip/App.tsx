import { Text, TextInput, View } from 'react-native';
import { styles } from './src/components/styles';

export default function App() {
  return (
    <View style = {styles.container}>
      <Text>Realizou todas as tarefas?</Text>
      <Text>Adicione tarefas a sua lista de pendências</Text>
      <TextInput>
        Descrição da tarefa
      </TextInput>
    </View>
    
  );
}
