import { View } from "react-native";

export default function App() {
    <View>
        <View>

        </View>

        <View>

        </View>
    </View>
}