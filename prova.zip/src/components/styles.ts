import { StyleSheet, TextInput } from "react-native"

export const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#7A4A9E',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#f2f2f2',
    },
})